﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnReturnToLogin = New System.Windows.Forms.Button()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.dgvHistory = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbFilterByPSUID = New System.Windows.Forms.ComboBox()
        Me.btnFilterByID = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnShowAllHistory = New System.Windows.Forms.Button()
        Me.btnFilterByDateTime = New System.Windows.Forms.Button()
        Me.SL_BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SL_DataSet = New SUNLabAccess.SUNLabAccessDataSet()
        Me.SL_AccessTableAdapter = New SUNLabAccess.SUNLabAccessDataSetTableAdapters.AccessTableAdapter()
        Me.SL_AdminLoginTableAdapter = New SUNLabAccess.SUNLabAccessDataSetTableAdapters.AdminLoginTableAdapter()
        Me.SL_UsersTableAdapter = New SUNLabAccess.SUNLabAccessDataSetTableAdapters.UsersTableAdapter()
        Me.mtxbStartDate = New System.Windows.Forms.MaskedTextBox()
        Me.mtxbEndDate = New System.Windows.Forms.MaskedTextBox()
        Me.mtxbStartTime = New System.Windows.Forms.MaskedTextBox()
        Me.mtxbEndTime = New System.Windows.Forms.MaskedTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmbChangeSUNLabAccessPrivileges = New System.Windows.Forms.ComboBox()
        Me.btnChangeAccessPrivileges = New System.Windows.Forms.Button()
        Me.dgvAccessPrivileges = New System.Windows.Forms.DataGridView()
        Me.Label9 = New System.Windows.Forms.Label()
        CType(Me.dgvHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SL_BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SL_DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvAccessPrivileges, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnReturnToLogin
        '
        Me.btnReturnToLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturnToLogin.Location = New System.Drawing.Point(807, 489)
        Me.btnReturnToLogin.Name = "btnReturnToLogin"
        Me.btnReturnToLogin.Size = New System.Drawing.Size(166, 40)
        Me.btnReturnToLogin.TabIndex = 11
        Me.btnReturnToLogin.Text = "Return to Login"
        Me.btnReturnToLogin.UseVisualStyleBackColor = True
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.Location = New System.Drawing.Point(12, 9)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(55, 20)
        Me.lblUser.TabIndex = 13
        Me.lblUser.Text = "User: "
        '
        'dgvHistory
        '
        Me.dgvHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvHistory.Location = New System.Drawing.Point(17, 74)
        Me.dgvHistory.MultiSelect = False
        Me.dgvHistory.Name = "dgvHistory"
        Me.dgvHistory.ReadOnly = True
        Me.dgvHistory.RowHeadersVisible = False
        Me.dgvHistory.RowHeadersWidth = 51
        Me.dgvHistory.RowTemplate.Height = 24
        Me.dgvHistory.Size = New System.Drawing.Size(426, 270)
        Me.dgvHistory.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(197, 20)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "SUN Lab Access History"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(627, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(130, 20)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Filter by PSU ID"
        '
        'cmbFilterByPSUID
        '
        Me.cmbFilterByPSUID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFilterByPSUID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbFilterByPSUID.FormattingEnabled = True
        Me.cmbFilterByPSUID.Location = New System.Drawing.Point(573, 97)
        Me.cmbFilterByPSUID.Name = "cmbFilterByPSUID"
        Me.cmbFilterByPSUID.Size = New System.Drawing.Size(176, 33)
        Me.cmbFilterByPSUID.TabIndex = 17
        '
        'btnFilterByID
        '
        Me.btnFilterByID.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFilterByID.Location = New System.Drawing.Point(755, 98)
        Me.btnFilterByID.Name = "btnFilterByID"
        Me.btnFilterByID.Size = New System.Drawing.Size(87, 33)
        Me.btnFilterByID.TabIndex = 18
        Me.btnFilterByID.Text = "Search"
        Me.btnFilterByID.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(616, 175)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(152, 20)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Filter by Date/Time"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(524, 205)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(209, 20)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Start Date (YYYY-MM-DD)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(531, 244)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(202, 20)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "End Date (YYYY-MM-DD)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(570, 282)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(163, 20)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Start Time (HH:MM)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(577, 320)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(156, 20)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "End Time (HH:MM)"
        '
        'btnShowAllHistory
        '
        Me.btnShowAllHistory.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowAllHistory.Location = New System.Drawing.Point(279, 31)
        Me.btnShowAllHistory.Name = "btnShowAllHistory"
        Me.btnShowAllHistory.Size = New System.Drawing.Size(164, 40)
        Me.btnShowAllHistory.TabIndex = 32
        Me.btnShowAllHistory.Text = "Show All History"
        Me.btnShowAllHistory.UseVisualStyleBackColor = True
        '
        'btnFilterByDateTime
        '
        Me.btnFilterByDateTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFilterByDateTime.Location = New System.Drawing.Point(874, 256)
        Me.btnFilterByDateTime.Name = "btnFilterByDateTime"
        Me.btnFilterByDateTime.Size = New System.Drawing.Size(88, 33)
        Me.btnFilterByDateTime.TabIndex = 33
        Me.btnFilterByDateTime.Text = "Search"
        Me.btnFilterByDateTime.UseVisualStyleBackColor = True
        '
        'SL_BindingSource
        '
        Me.SL_BindingSource.DataMember = "Users"
        Me.SL_BindingSource.DataSource = Me.SL_DataSet
        '
        'SL_DataSet
        '
        Me.SL_DataSet.DataSetName = "SUNLabAccessDataSet"
        Me.SL_DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SL_AccessTableAdapter
        '
        Me.SL_AccessTableAdapter.ClearBeforeFill = True
        '
        'SL_AdminLoginTableAdapter
        '
        Me.SL_AdminLoginTableAdapter.ClearBeforeFill = True
        '
        'SL_UsersTableAdapter
        '
        Me.SL_UsersTableAdapter.ClearBeforeFill = True
        '
        'mtxbStartDate
        '
        Me.mtxbStartDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mtxbStartDate.Location = New System.Drawing.Point(755, 202)
        Me.mtxbStartDate.Mask = "0000-00-00"
        Me.mtxbStartDate.Name = "mtxbStartDate"
        Me.mtxbStartDate.Size = New System.Drawing.Size(113, 27)
        Me.mtxbStartDate.TabIndex = 34
        '
        'mtxbEndDate
        '
        Me.mtxbEndDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mtxbEndDate.Location = New System.Drawing.Point(755, 241)
        Me.mtxbEndDate.Mask = "0000-00-00"
        Me.mtxbEndDate.Name = "mtxbEndDate"
        Me.mtxbEndDate.Size = New System.Drawing.Size(113, 27)
        Me.mtxbEndDate.TabIndex = 35
        '
        'mtxbStartTime
        '
        Me.mtxbStartTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mtxbStartTime.Location = New System.Drawing.Point(755, 279)
        Me.mtxbStartTime.Mask = "00:00"
        Me.mtxbStartTime.Name = "mtxbStartTime"
        Me.mtxbStartTime.Size = New System.Drawing.Size(56, 27)
        Me.mtxbStartTime.TabIndex = 36
        Me.mtxbStartTime.ValidatingType = GetType(Date)
        '
        'mtxbEndTime
        '
        Me.mtxbEndTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mtxbEndTime.Location = New System.Drawing.Point(755, 317)
        Me.mtxbEndTime.Mask = "00:00"
        Me.mtxbEndTime.Name = "mtxbEndTime"
        Me.mtxbEndTime.Size = New System.Drawing.Size(56, 27)
        Me.mtxbEndTime.TabIndex = 37
        Me.mtxbEndTime.ValidatingType = GetType(Date)
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(568, 390)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(278, 20)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Change SUN Lab Access Privileges"
        '
        'cmbChangeSUNLabAccessPrivileges
        '
        Me.cmbChangeSUNLabAccessPrivileges.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbChangeSUNLabAccessPrivileges.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbChangeSUNLabAccessPrivileges.FormattingEnabled = True
        Me.cmbChangeSUNLabAccessPrivileges.Location = New System.Drawing.Point(574, 413)
        Me.cmbChangeSUNLabAccessPrivileges.Name = "cmbChangeSUNLabAccessPrivileges"
        Me.cmbChangeSUNLabAccessPrivileges.Size = New System.Drawing.Size(176, 33)
        Me.cmbChangeSUNLabAccessPrivileges.TabIndex = 39
        '
        'btnChangeAccessPrivileges
        '
        Me.btnChangeAccessPrivileges.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChangeAccessPrivileges.Location = New System.Drawing.Point(755, 413)
        Me.btnChangeAccessPrivileges.Name = "btnChangeAccessPrivileges"
        Me.btnChangeAccessPrivileges.Size = New System.Drawing.Size(87, 33)
        Me.btnChangeAccessPrivileges.TabIndex = 40
        Me.btnChangeAccessPrivileges.Text = "Change"
        Me.btnChangeAccessPrivileges.UseVisualStyleBackColor = True
        '
        'dgvAccessPrivileges
        '
        Me.dgvAccessPrivileges.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvAccessPrivileges.Location = New System.Drawing.Point(17, 390)
        Me.dgvAccessPrivileges.MultiSelect = False
        Me.dgvAccessPrivileges.Name = "dgvAccessPrivileges"
        Me.dgvAccessPrivileges.ReadOnly = True
        Me.dgvAccessPrivileges.RowHeadersVisible = False
        Me.dgvAccessPrivileges.RowHeadersWidth = 51
        Me.dgvAccessPrivileges.RowTemplate.Height = 24
        Me.dgvAccessPrivileges.Size = New System.Drawing.Size(272, 139)
        Me.dgvAccessPrivileges.TabIndex = 41
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(13, 367)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(216, 20)
        Me.Label9.TabIndex = 42
        Me.Label9.Text = "SUN Lab Access Privileges"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(983, 541)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.dgvAccessPrivileges)
        Me.Controls.Add(Me.btnChangeAccessPrivileges)
        Me.Controls.Add(Me.cmbChangeSUNLabAccessPrivileges)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.mtxbEndTime)
        Me.Controls.Add(Me.mtxbStartTime)
        Me.Controls.Add(Me.mtxbEndDate)
        Me.Controls.Add(Me.mtxbStartDate)
        Me.Controls.Add(Me.btnFilterByDateTime)
        Me.Controls.Add(Me.btnShowAllHistory)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnFilterByID)
        Me.Controls.Add(Me.cmbFilterByPSUID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvHistory)
        Me.Controls.Add(Me.lblUser)
        Me.Controls.Add(Me.btnReturnToLogin)
        Me.Name = "Form2"
        Me.ShowIcon = False
        Me.Text = "SUN Lab Access - Admin"
        CType(Me.dgvHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SL_BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SL_DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvAccessPrivileges, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnReturnToLogin As Button
    Friend WithEvents lblUser As Label
    Friend WithEvents SUNLabAccessDataSet As SUNLabAccessDataSet
    Friend WithEvents AccessTableAdapter As SUNLabAccessDataSetTableAdapters.AccessTableAdapter
    Friend WithEvents AdminLoginTableAdapter As SUNLabAccessDataSetTableAdapters.AdminLoginTableAdapter
    Friend WithEvents UsersTableAdapter As SUNLabAccessDataSetTableAdapters.UsersTableAdapter
    Friend WithEvents dgvHistory As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cmbFilterByPSUID As ComboBox
    Friend WithEvents btnFilterByID As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btnShowAllHistory As Button
    Friend WithEvents btnFilterByDateTime As Button
    Friend WithEvents SL_BindingSource As BindingSource
    Friend WithEvents SL_DataSet As SUNLabAccessDataSet
    Friend WithEvents SL_AccessTableAdapter As SUNLabAccessDataSetTableAdapters.AccessTableAdapter
    Friend WithEvents SL_AdminLoginTableAdapter As SUNLabAccessDataSetTableAdapters.AdminLoginTableAdapter
    Friend WithEvents SL_UsersTableAdapter As SUNLabAccessDataSetTableAdapters.UsersTableAdapter
    Friend WithEvents mtxbStartDate As MaskedTextBox
    Friend WithEvents mtxbEndDate As MaskedTextBox
    Friend WithEvents mtxbStartTime As MaskedTextBox
    Friend WithEvents mtxbEndTime As MaskedTextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents cmbChangeSUNLabAccessPrivileges As ComboBox
    Friend WithEvents btnChangeAccessPrivileges As Button
    Friend WithEvents dgvAccessPrivileges As DataGridView
    Friend WithEvents Label9 As Label
End Class
