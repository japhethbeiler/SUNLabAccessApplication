﻿Imports Microsoft.VisualBasic.ApplicationServices

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Load data into the SL_DataSet tables
        SL_AdminLoginTableAdapter.Fill(SL_DataSet.AdminLogin)
        SL_UsersTableAdapter.Fill(SL_DataSet.Users)
        SL_AccessTableAdapter.Fill(SL_DataSet.Access)

        'Fill the Admin Login PSU ID combo box
        Dim query1 = From users In SL_DataSet.AdminLogin
                     Order By users.UserID
                     Select users.UserID
        cmbAdminID.DataSource = query1.ToList()

        'Fill the SUN Lab Access PSU ID combo box
        Dim query2 = From users In SL_DataSet.Users
                     Order By users.UserID
                     Select users.UserID
        cmbUserID.DataSource = query2.ToList()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim adminID As Integer = CInt(cmbAdminID.Text)
        Dim password As String = txbAdminPassword.Text
        txbAdminPassword.Clear()

        'Get the password from the database
        Dim query = From users In SL_DataSet.AdminLogin
                    Where users.UserID = adminID
                    Select users.AdminPassword

        'Compare the password from the database and the password entered by the user
        Try
            If query(0) = password Then
                Me.Hide()
                Dim newForm As New Form2(Me, adminID)
                newForm.Show()
            Else
                MessageBox.Show("Incorrect Password")
            End If
        Catch ex As Exception
            MessageBox.Show("There are currently no users stored.")
        End Try
    End Sub

    Private Sub btnSwipeIn_Click(sender As Object, e As EventArgs) Handles btnSwipeIn.Click
        Dim userID As Integer = CInt(cmbUserID.Text)

        Dim query = From user In SL_DataSet.Users
                    Let isActive = user.IsActive
                    Where user.UserID = userID
                    Select isActive

        If query(0) Then
            Try
                'Create a new row in the Access table and enter the data
                Dim newAccessRow As SUNLabAccessDataSet.AccessRow = SL_DataSet.Access.NewAccessRow()
                newAccessRow.UserID = userID
                newAccessRow.SwipeDatetime = Now
                newAccessRow.SwipeInOut = "In"

                'Add the new row to the dataset's Access table and update the database
                SL_DataSet.Access.AddAccessRow(newAccessRow)
                SL_AccessTableAdapter.Update(SL_DataSet.Access)

                MessageBox.Show("Swipe in successful")

            Catch ex As Exception
                MessageBox.Show("Swipe in failed")
            End Try
        Else
            MessageBox.Show("User " & userID & " is not authorized to to access the SUN Lab.")
        End If
    End Sub

    Private Sub btnSwipeOut_Click(sender As Object, e As EventArgs) Handles btnSwipeOut.Click
        Dim userID As Integer = CInt(cmbUserID.Text)

        Dim query = From user In SL_DataSet.Users
                    Let isActive = user.IsActive
                    Where user.UserID = userID
                    Select isActive

        If query(0) Then
            Try
                'Create a new row in the Access table and enter the data
                Dim newAccessRow As SUNLabAccessDataSet.AccessRow = SL_DataSet.Access.NewAccessRow()
                newAccessRow.UserID = userID
                newAccessRow.SwipeDatetime = Now
                newAccessRow.SwipeInOut = "Out"

                'Add the new row to the dataset's Access table and update the database
                SL_DataSet.Access.AddAccessRow(newAccessRow)
                SL_AccessTableAdapter.Update(SL_DataSet.Access)

                MessageBox.Show("Swipe out successful")

            Catch ex As Exception
                MessageBox.Show("Swipe out failed")
            End Try
        Else
            MessageBox.Show("User " & userID & " is not authorized to to access the SUN Lab.")
        End If
    End Sub
End Class