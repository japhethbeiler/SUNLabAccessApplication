﻿Imports Microsoft.VisualBasic.ApplicationServices

Public Class Form2
    Private main As Form1
    Private adminID As Integer

    Public Sub New(m As Form1, id As Integer)
        main = m
        adminID = id
        InitializeComponent()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Load data into the SL_DataSet tables
        SL_AdminLoginTableAdapter.Fill(SL_DataSet.AdminLogin)
        SL_UsersTableAdapter.Fill(SL_DataSet.Users)
        SL_AccessTableAdapter.Fill(SL_DataSet.Access)

        'Display the user's name
        Dim query1 = From users In SL_DataSet.Users
                     Where users.UserID = adminID
                     Let name = CStr(users.FirstName & " " & users.LastName)
                     Select name
        lblUser.Text = "User: " & query1(0)

        'Fill the "SUN Lab Access History" data grid view with the complete SUN Lab access history
        displaySUNLabAccessHistory()

        'Fill the "SUN Lab Access Privileges" data grid view with the SUN Lab users and their access privileges
        displaySUNLabAccessPrivileges()

        'Fill the "Filter by PSU ID" and "Change SUN Lab Access Privileges" combo boxes
        Dim query2 = From users In SL_DataSet.Users
                     Order By users.UserID
                     Select users.UserID
        cmbFilterByPSUID.DataSource = query2.ToList()
        cmbChangeSUNLabAccessPrivileges.DataSource = query2.ToList()
    End Sub

    Private Sub btnShowAllHistory_Click(sender As Object, e As EventArgs) Handles btnShowAllHistory.Click
        displaySUNLabAccessHistory()
    End Sub

    Private Sub displaySUNLabAccessHistory()
        Dim query = From users1 In SL_DataSet.Access
                    Join users2 In SL_DataSet.Users
                     On users1.UserID Equals users2.UserID
                    Let name = CStr(users2.FirstName & " " & users2.LastName)
                    Order By users1.SwipeDatetime Descending
                    Select users1.UserID, name, users1.SwipeDatetime, users1.SwipeInOut

        dgvHistory.DataSource = query.ToList
        dgvHistory.Columns(0).HeaderText = "PSU ID"
        dgvHistory.Columns(1).HeaderText = "Name"
        dgvHistory.Columns(2).HeaderText = "Date/Time"
        dgvHistory.Columns(3).HeaderText = "In/Out"
        dgvHistory.AutoResizeColumn(0)
        dgvHistory.AutoResizeColumn(1)
        dgvHistory.AutoResizeColumn(2)
        dgvHistory.AutoResizeColumn(3)
    End Sub

    Private Sub displaySUNLabAccessPrivileges()
        Dim query = From users In SL_DataSet.Users
                    Let name = CStr(users.FirstName & " " & users.LastName)
                    Let status = users.IsActive
                    Order By users.UserID
                    Select users.UserID, name, status

        dgvAccessPrivileges.DataSource = query.ToList
        dgvAccessPrivileges.Columns(0).HeaderText = "PSU ID"
        dgvAccessPrivileges.Columns(1).HeaderText = "Name"
        dgvAccessPrivileges.Columns(2).HeaderText = "Is Active"
        dgvAccessPrivileges.AutoResizeColumn(0)
        dgvAccessPrivileges.AutoResizeColumn(1)
        dgvAccessPrivileges.AutoResizeColumn(2)
    End Sub

    Private Sub btnFilterByID_Click(sender As Object, e As EventArgs) Handles btnFilterByID.Click
        Dim id As Integer = CInt(cmbFilterByPSUID.Text)

        Dim query = From user1 In SL_DataSet.Access
                    Join user2 In SL_DataSet.Users
                    On user1.UserID Equals user2.UserID
                    Let name = CStr(user2.FirstName & " " & user2.LastName)
                    Where user1.UserID = id
                    Order By user1.SwipeDatetime
                    Select user1.UserID, name, user1.SwipeDatetime, user1.SwipeInOut

        dgvHistory.DataSource = query.ToList
    End Sub

    Private Sub btnFilterByDateTime_Click(sender As Object, e As EventArgs) Handles btnFilterByDateTime.Click
        Dim startDate As String = CStr(mtxbStartDate.Text)
        Dim endDate As String = CStr(mtxbEndDate.Text)
        Dim startTime As String = CStr(mtxbStartTime.Text)
        Dim endTime As String = CStr(mtxbEndTime.Text)

        If mtxbStartDate.MaskCompleted AndAlso mtxbEndDate.MaskCompleted AndAlso mtxbStartTime.MaskCompleted AndAlso mtxbEndTime.MaskCompleted Then
            'Filter by date and time
            Dim query = From user1 In SL_DataSet.Access
                        Join user2 In SL_DataSet.Users
                        On user1.UserID Equals user2.UserID
                        Let name = CStr(user2.FirstName & " " & user2.LastName)
                        Where CDate(user1.SwipeDatetime) > startDate AndAlso CDate(user1.SwipeDatetime) < DateAdd("d", 1, endDate) AndAlso TimeValue(user1.SwipeDatetime) > startTime AndAlso TimeValue(user1.SwipeDatetime) < DateAdd("n", 1, endTime)
                        Order By user1.SwipeDatetime
                        Select user1.UserID, name, user1.SwipeDatetime, user1.SwipeInOut
            dgvHistory.DataSource = query.ToList

        ElseIf mtxbStartDate.MaskCompleted AndAlso mtxbEndDate.MaskCompleted Then
            'Filter by date only
            Dim query = From user1 In SL_DataSet.Access
                        Join user2 In SL_DataSet.Users
                        On user1.UserID Equals user2.UserID
                        Let name = CStr(user2.FirstName & " " & user2.LastName)
                        Where CDate(user1.SwipeDatetime) > startDate AndAlso CDate(user1.SwipeDatetime) < DateAdd("d", 1, endDate)
                        Order By user1.SwipeDatetime
                        Select user1.UserID, name, user1.SwipeDatetime, user1.SwipeInOut
            dgvHistory.DataSource = query.ToList

        ElseIf mtxbStartTime.MaskCompleted AndAlso mtxbEndTime.MaskCompleted Then
            'Filter by time only
            Dim query = From user1 In SL_DataSet.Access
                        Join user2 In SL_DataSet.Users
                        On user1.UserID Equals user2.UserID
                        Let name = CStr(user2.FirstName & " " & user2.LastName)
                        Where TimeValue(user1.SwipeDatetime) > startTime AndAlso TimeValue(user1.SwipeDatetime) < DateAdd("n", 1, endTime)
                        Order By user1.SwipeDatetime
                        Select user1.UserID, name, user1.SwipeDatetime, user1.SwipeInOut
            dgvHistory.DataSource = query.ToList

        Else
            displaySUNLabAccessHistory()
            MessageBox.Show("Input is not valid. Now displaying all history.")
        End If
    End Sub

    Private Sub btnChangeAccessPrivileges_Click(sender As Object, e As EventArgs) Handles btnChangeAccessPrivileges.Click
        Dim id As Integer = CInt(cmbChangeSUNLabAccessPrivileges.Text)

        Try
            'Find the row in the Users table and update the data
            Dim usersRow As SUNLabAccessDataSet.UsersRow = SL_DataSet.Users.FindByUserID(id)
            usersRow.IsActive = Not (usersRow.IsActive)

            ' Update the database
            SL_UsersTableAdapter.Update(SL_DataSet.Users)

        Catch ex As Exception
            MessageBox.Show("Update failed")
        End Try

        displaySUNLabAccessPrivileges()
    End Sub

    Private Sub btnReturnToLogin_Click(sender As Object, e As EventArgs) Handles btnReturnToLogin.Click
        Close()
        Application.Restart()
    End Sub

    Protected Overrides Sub OnFormClosing(ByVal e As FormClosingEventArgs)
        Application.Exit()
    End Sub
End Class