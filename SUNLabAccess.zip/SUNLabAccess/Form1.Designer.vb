﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbAdminID = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txbAdminPassword = New System.Windows.Forms.TextBox()
        Me.btnSwipeIn = New System.Windows.Forms.Button()
        Me.btnSwipeOut = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmbUserID = New System.Windows.Forms.ComboBox()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.SL_BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SL_DataSet = New SUNLabAccess.SUNLabAccessDataSet()
        Me.SL_AdminLoginTableAdapter = New SUNLabAccess.SUNLabAccessDataSetTableAdapters.AdminLoginTableAdapter()
        Me.SL_UsersTableAdapter = New SUNLabAccess.SUNLabAccessDataSetTableAdapters.UsersTableAdapter()
        Me.SL_AccessTableAdapter = New SUNLabAccess.SUNLabAccessDataSetTableAdapters.AccessTableAdapter()
        CType(Me.SL_BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SL_DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(71, 196)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "PSU ID"
        '
        'cmbAdminID
        '
        Me.cmbAdminID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAdminID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbAdminID.FormattingEnabled = True
        Me.cmbAdminID.Location = New System.Drawing.Point(160, 193)
        Me.cmbAdminID.Name = "cmbAdminID"
        Me.cmbAdminID.Size = New System.Drawing.Size(176, 33)
        Me.cmbAdminID.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(159, 131)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 25)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Admin Login"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(497, 131)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(176, 25)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "SUN Lab Access"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(50, 256)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 25)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Password"
        '
        'txbAdminPassword
        '
        Me.txbAdminPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbAdminPassword.Location = New System.Drawing.Point(160, 253)
        Me.txbAdminPassword.Name = "txbAdminPassword"
        Me.txbAdminPassword.Size = New System.Drawing.Size(176, 30)
        Me.txbAdminPassword.TabIndex = 5
        Me.txbAdminPassword.UseSystemPasswordChar = True
        '
        'btnSwipeIn
        '
        Me.btnSwipeIn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSwipeIn.Location = New System.Drawing.Point(439, 246)
        Me.btnSwipeIn.Name = "btnSwipeIn"
        Me.btnSwipeIn.Size = New System.Drawing.Size(145, 45)
        Me.btnSwipeIn.TabIndex = 6
        Me.btnSwipeIn.Text = "Swipe In"
        Me.btnSwipeIn.UseVisualStyleBackColor = True
        '
        'btnSwipeOut
        '
        Me.btnSwipeOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSwipeOut.Location = New System.Drawing.Point(590, 246)
        Me.btnSwipeOut.Name = "btnSwipeOut"
        Me.btnSwipeOut.Size = New System.Drawing.Size(145, 45)
        Me.btnSwipeOut.TabIndex = 7
        Me.btnSwipeOut.Text = "Swipe Out"
        Me.btnSwipeOut.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(455, 196)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 25)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "PSU ID"
        '
        'cmbUserID
        '
        Me.cmbUserID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbUserID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbUserID.FormattingEnabled = True
        Me.cmbUserID.Location = New System.Drawing.Point(543, 193)
        Me.cmbUserID.Name = "cmbUserID"
        Me.cmbUserID.Size = New System.Drawing.Size(176, 33)
        Me.cmbUserID.TabIndex = 9
        '
        'btnLogin
        '
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.Location = New System.Drawing.Point(177, 304)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(145, 45)
        Me.btnLogin.TabIndex = 10
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'SL_BindingSource
        '
        Me.SL_BindingSource.DataMember = "Access"
        Me.SL_BindingSource.DataSource = Me.SL_DataSet
        '
        'SL_DataSet
        '
        Me.SL_DataSet.DataSetName = "SUNLabAccessDataSet"
        Me.SL_DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SL_AdminLoginTableAdapter
        '
        Me.SL_AdminLoginTableAdapter.ClearBeforeFill = True
        '
        'SL_UsersTableAdapter
        '
        Me.SL_UsersTableAdapter.ClearBeforeFill = True
        '
        'SL_AccessTableAdapter
        '
        Me.SL_AccessTableAdapter.ClearBeforeFill = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.cmbUserID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnSwipeOut)
        Me.Controls.Add(Me.btnSwipeIn)
        Me.Controls.Add(Me.txbAdminPassword)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbAdminID)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.Text = "SUN Lab Access"
        CType(Me.SL_BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SL_DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents cmbAdminID As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txbAdminPassword As TextBox
    Friend WithEvents btnSwipeIn As Button
    Friend WithEvents btnSwipeOut As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents cmbUserID As ComboBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents SL_BindingSource As BindingSource
    Friend WithEvents SL_DataSet As SUNLabAccessDataSet
    Friend WithEvents SL_AdminLoginTableAdapter As SUNLabAccessDataSetTableAdapters.AdminLoginTableAdapter
    Friend WithEvents SL_UsersTableAdapter As SUNLabAccessDataSetTableAdapters.UsersTableAdapter
    Friend WithEvents SL_AccessTableAdapter As SUNLabAccessDataSetTableAdapters.AccessTableAdapter
End Class
